namespace AIMLbot.Utils
{
    /// <summary>
    /// Used to determine the Gender of things
    /// </summary>
    public enum Gender
    {
        Unknown = -1,
        Female = 0,
        Male = 1
    }
}