﻿namespace AIMLbot.Utils
{
    public enum LevelSetting
    {
        High,
        Medium,
        Low,
        None
    }
}